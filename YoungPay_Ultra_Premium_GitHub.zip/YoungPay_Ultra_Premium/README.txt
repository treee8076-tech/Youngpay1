YOUNGPAY ULTRA PREMIUM LANDING PAGE
=================================

Included:
- index.html (complete responsive website, no build tools required)
- youngpay-banner.png (promotional banner)
- VID_20261112_201149_794.mp4 (uploaded 95-second explainer video)

LINKS ALREADY CONFIGURED
Registration: https://app-web.youngpay-web.com/regist?code=1smartwamat2
Telegram: https://t.me/+7XgRG0xG_RZiMzg1

GITHUB PAGES SETUP
1. Create a new public GitHub repository.
2. Upload these 3 files (index.html, youngpay-banner.png, VID_20261112_201149_794.mp4) to the ROOT of the repo, not inside a nested folder.
3. Commit changes.
4. Go to Settings > Pages > Build and deployment.
5. Choose Deploy from a branch, main, /(root), then Save.
6. GitHub will show the site URL once deployment completes.

The video is roughly 22 MB. GitHub accepts this size but visitors will use data to watch it.
The image/video are relative local assets; do not rename files without updating index.html.
The fonts load from Google Fonts when online; system fonts are used as fallback.

IMPORTANT ADVERTISING NOTES
The page labels this as a Buy/Sell commission platform rather than a salaried job.
The Rs 150 signup bonus is conditional on qualifying tasks.
4% commission shown as advertised, not a guaranteed profit.
Verify actual bonus, commission, payment and withdrawal rules and any required legal disclosures before running ads.
